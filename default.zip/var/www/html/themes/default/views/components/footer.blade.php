<footer class="pt-5 pb-3 mt-auto">
    <div class="text-sm text-center content text-secondary-600">
        <a href="https://enderhosting.com.mx" target="_blank">
        &copy; EnderHosting 2023 - {{ date('Y') }}
        </a>
        <p>&</p>
        <a href="https://paymenter.org" target="_blank">
        &copy;  Paymenter 2022 - {{ date('Y') }}
        </a>
    </div>
</footer>
