<x-admin-layout>
    <x-slot name="title">
        {{ __('Orders') }}
    </x-slot>
    <h1 class="text-center text-2xl font-bold">{{ __('Orders') }}</h1>

    <livewire:admin.orders />
</x-admin-layout>
